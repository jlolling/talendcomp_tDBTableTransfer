package sqlrunner;

public interface MacOSXAdapterInterface {

	void setup();
	
}
