package sqlrunner;

import java.net.InetAddress;
import java.net.UnknownHostException;

public final class Guid extends Object {

    private static int        counter   = 0;
    private static final byte shiftab[] = { 0, 8, 16, 24, 32, 40, 48, 56 };

    private Guid() {}

    public synchronized static String nextGuid() {
        try {
            counter++;
            final InetAddress id = InetAddress.getLocalHost();
            final byte[] ip = id.getAddress();
            final long time = System.currentTimeMillis();
            byte[] guid = new byte[16];
            for (int i = 0; i <= 3; i++) {
                guid[i] = ip[i];
            }
            longToBytes(time, guid, 4);
            intToBytes(counter, guid, 12);
            final StringBuffer str = new StringBuffer();
            str.append(Long.toHexString(bytesToLong(guid, 0)));
            str.append(Long.toHexString(bytesToLong(guid, 8)));
            return str.toString().toUpperCase();
        } catch (UnknownHostException e) {
            return null;
        }
    }

    private static long bytesToLong(byte[] ba, int offset) throws IllegalArgumentException {
        if (ba == null) {
            throw new IllegalArgumentException("null as byte array is not allowed");
        }
        long i = 0;
        for (int j = 0; j < 8; j++) {
            i |= ((long) ba[offset + 7 - j] << shiftab[j]) & (0xFFL << shiftab[j]);
        }
        return i;
    }

    private static void longToBytes(long i, byte[] ba, int offset) throws IllegalArgumentException {
        if (ba == null) {
            throw new IllegalArgumentException("null as byte array is not allowed");
        }
        for (int j = 0; j < 8; j++) {
            ba[offset + j] = (byte) ((i >>> shiftab[7 - j]) & 0xFF);
        }
    }

    private static void intToBytes(int i, byte[] ba, int offset) throws IllegalArgumentException {
        if (ba == null) {
            throw new IllegalArgumentException("null as byte array is not allowed");
        }
        for (int j = 0; j < 4; j++) {
            ba[offset + j] = (byte) ((i >>> shiftab[3 - j]) & 0xFF);
        }
    }

}
